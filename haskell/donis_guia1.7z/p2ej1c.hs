safeLast :: [a] -> Maybe a

safeLast [] = Nothing
safeLast [x] = Just x
safeLast (_:xs) = safeLast xs
