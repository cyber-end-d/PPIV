import System.Environment (getArgs)
import Data.List

--La keyword do introduce un bloque de acciones
--que pueden causar efectos exteriores,
--como leer o escribir en un archivo

interactWith function inputFile outputFile = do
    input <- readFile inputFile
    writeFile outputFile (function input)

main = mainWith myFunction
    where mainWith function = do
              args <- getArgs
              case args of
                   [input,output] -> interactWith function input output
                   _ -> putStrLn "error: se necesitan dos argumentos"

--reemplazar "id" por el nombre de la funcion a probar
myFunction = fixLines

descomp [] = []
descomp (xs) = [[head xs]] ++ descomp (tail xs)

transponer xs = zipWith (++) (descomp (head (lines xs))) (descomp (head (tail (lines xs))))

fixLines input = unlines (transponer input)
