cdad (x:xs) = 1 + cdad xs
cdad [] = 0