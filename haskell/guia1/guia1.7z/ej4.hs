toPalindromo (x:xs) = if null xs
				then [x]
				else [x] ++ toPalindromo(xs) ++ [x]